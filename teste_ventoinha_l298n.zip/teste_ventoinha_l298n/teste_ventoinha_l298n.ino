// TESTE VENTOINHA COM L298N
// OUT1 / OUT2 -> Ventoinha
// IN1 -> D2
// IN2 -> D4
// ENA -> D5
// 12V -> positivo das baterias
// GND -> negativo das baterias e GND do Arduino

#define IN1 2
#define IN2 4
#define ENA 5

void setup() {
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENA, OUTPUT);

  // Liga a ventoinha ao iniciar
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
  analogWrite(ENA, 255);
}

void loop() {
}
