// TESTE KY-026 COM DETECCAO DE CHAMA
// AO -> A0
// VCC -> 5V
// GND -> GND

#define IR_ANALOGICO A0

int valorBase = 0;
int margem = 80;

void setup() {
  Serial.begin(9600);

  Serial.println("Calibrando sensor...");
  Serial.println("Mantenha o sensor livre durante a calibracao");

  delay(3000);

  long soma = 0;

  for (int i = 0; i < 30; i++) {
    soma = soma + analogRead(IR_ANALOGICO);
    delay(100);
  }

  valorBase = soma / 30;

  Serial.print("Valor base: ");
  Serial.println(valorBase);
  Serial.println("Sensor calibrado");
  Serial.println("------------------------------------");
}

void loop() {
  int valorIR = analogRead(IR_ANALOGICO);
  int diferenca = abs(valorIR - valorBase);

  Serial.print("Valor IR: ");
  Serial.print(valorIR);

  Serial.print(" | Base: ");
  Serial.print(valorBase);

  Serial.print(" | Diferenca: ");
  Serial.print(diferenca);

  if (diferenca > margem) {
    Serial.println(" | CHAMA DETECTADA");
  } else {
    Serial.println(" | Sem chama");
  }

  delay(300);
}