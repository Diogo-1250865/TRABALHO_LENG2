#include "DHT.h"

#define DHTPIN 7
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

#define TRIG_PIN 8
#define ECHO_PIN 9

void setup() {
  Serial.begin(9600);
  delay(1000);

  dht.begin();

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  Serial.println("Teste DHT22 + HC-SR04 iniciado");
}

void loop() {
  leerDHT22();
  leerDistancia();

  Serial.println("-----------------------------");
  delay(2000);
}

void leerDHT22() {
  float temperatura = dht.readTemperature();
  float humedad = dht.readHumidity();

  if (isnan(temperatura) || isnan(humedad)) {
    Serial.println("Erro ao ler o sensor DHT22");
  } else {
    Serial.print("Temperatura: ");
    Serial.print(temperatura);
    Serial.println(" C");

    Serial.print("Humidade: ");
    Serial.print(humedad);
    Serial.println(" %");
  }
}

void leerDistancia() {
  long duracion;
  float distancia_cm;
  float distancia_m;

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  duracion = pulseIn(ECHO_PIN, HIGH, 30000);

  if (duracion == 0) {
    Serial.println("Distancia: sem leitura / fora de alcance");
  } else {
    distancia_cm = duracion * 0.0343 / 2;
    distancia_m = distancia_cm / 100.0;

    Serial.print("Distancia: ");
    Serial.print(distancia_cm);
    Serial.print(" cm | ");
    Serial.print(distancia_m);
    Serial.println(" m");
  }
}