// TESTE SERVO MG90S
// Sinal do servo -> D10
// VCC do servo -> 5V
// GND do servo -> GND

#include <Servo.h>

#define SERVO_PIN 10

Servo servoMotor;

void setup() {
  Serial.begin(9600);

  servoMotor.attach(SERVO_PIN);

  Serial.println("Teste Servo MG90S iniciado");
}

void loop() {
  Serial.println("Servo para 0 graus");
  servoMotor.write(0);
  delay(1000);

  Serial.println("Servo para 45 graus");
  servoMotor.write(45);
  delay(1000);

  Serial.println("Servo para 90 graus");
  servoMotor.write(90);
  delay(1000);

  Serial.println("Servo para 135 graus");
  servoMotor.write(135);
  delay(1000);

  Serial.println("Servo para 180 graus");
  servoMotor.write(180);
  delay(1000);

  Serial.println("Servo volta para 90 graus");
  servoMotor.write(90);
  delay(1500);

  Serial.println("----------------------");
}